# atividade 1
# print ("Python no Senac")

# atividade 2
# nome = input("Digite seu nome: ")
# ano_atual = int(input("Digite o ano atual: "))
# ano_nasc = int(input("Digite o ano de nascimento: "))
# idade = ano_atual - ano_nasc

# print(" Meu nome é {nome} e tenho {idade} anos ")

# atividade 3
# print("S")
# print("E")
# print("N")
# print("A")
# print("C")

# atividade 4
# pi = 3.14159
# print(f"O valor arredondado de pi é{pi:.2f}: ")